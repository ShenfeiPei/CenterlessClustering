from . import funs as Funs
from . import funs_metric as Mfuns
from . import funs_graph as Gfuns